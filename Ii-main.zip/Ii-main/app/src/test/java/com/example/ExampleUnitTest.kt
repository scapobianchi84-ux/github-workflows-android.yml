package com.example

import com.example.data.model.ChatMessage
import com.example.data.model.ChatSender
import com.example.data.model.Trip
import com.example.data.model.TripStop
import com.example.data.model.WeatherForecastDay
import com.example.data.remote.GeminiVacationService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun `test chat assistant returns curiosities for trip destination`() = runBlocking {
        val service = GeminiVacationService()
        val trip = Trip(
            id = 1L,
            title = "Weekend Romantico a Roma",
            destination = "Roma",
            interests = "Arte, Storia, Cibo tipico",
            durationDays = 3,
            startDate = "15 Maggio 2025",
            budgetTotal = 1500.0,
            currency = "€"
        )
        val stops = listOf(
            TripStop(
                id = 1L,
                tripId = 1L,
                dayNumber = 1,
                orderIndex = 0,
                timeSlot = "09:30 - 12:00",
                title = "Colosseo e Fori Imperiali",
                category = "Cultura",
                description = "Visita guidata ai monumenti antichi",
                estimatedCost = 35.0,
                durationMinutes = 150,
                latitude = 41.8902,
                longitude = 12.4922,
                addressOrLocation = "Piazza del Colosseo, 1, Roma"
            )
        )
        val weather = listOf(
            WeatherForecastDay(
                date = "15 Maggio",
                dayName = "Giorno 1",
                tempMax = 25.0,
                tempMin = 16.0,
                condition = "Soleggiato",
                rainChance = 10,
                weatherCode = 0,
                tip = "Clima perfetto per passeggiate"
            )
        )

        val response = service.askTripAssistant(
            trip = trip,
            stops = stops,
            weather = weather,
            conversationHistory = emptyList(),
            userQuestion = "Quali curiosità mi puoi raccontare su questa vacanza?"
        )

        assertNotNull(response)
        assertTrue(response.isNotEmpty())
        assertTrue(response.contains("Curiosità", ignoreCase = true) || response.contains("Roma", ignoreCase = true))
    }
}

