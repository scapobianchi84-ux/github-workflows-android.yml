package com.example.domain

import com.example.data.model.AbacusBudgetBreakdown
import com.example.data.model.HourlyCheckRecord
import com.example.data.model.Trip
import com.example.data.model.TripStop
import java.util.Calendar
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object AbacusOptimizer {

    fun calculateBudgetBreakdown(totalBudget: Double, durationDays: Int, stops: List<TripStop>): AbacusBudgetBreakdown {
        val totalDays = maxOf(1, durationDays)
        val activitiesTotal = stops.sumOf { it.estimatedCost }

        // Adaptive distribution
        val accommodationShare = (totalBudget * 0.38)
        val foodShare = (totalBudget * 0.24)
        val transportShare = (totalBudget * 0.14)
        val estimatedTotal = activitiesTotal + accommodationShare + foodShare + transportShare
        val bufferEmergency = maxOf(0.0, totalBudget - estimatedTotal)

        return AbacusBudgetBreakdown(
            accommodationCost = accommodationShare,
            foodCost = foodShare,
            activitiesCost = activitiesTotal,
            transportCost = transportShare,
            bufferEmergencyCost = bufferEmergency,
            totalEstimated = estimatedTotal,
            budgetTotal = totalBudget,
            remainingBudget = totalBudget - estimatedTotal,
            isUnderBudget = estimatedTotal <= totalBudget
        )
    }

    /**
     * Executes the hourly schedule audit requested by the user:
     * "mi controlla ogni ora tutto per garantire il massimo rispetto delle tempistiche pianificate"
     */
    fun performHourlyAudit(
        trip: Trip,
        dayStops: List<TripStop>,
        simulatedDelayMinutes: Int = 0
    ): HourlyCheckRecord {
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)
        val hourLabel = String.format("Ore %02d:00", currentHour)

        if (dayStops.isEmpty()) {
            return HourlyCheckRecord(
                tripId = trip.id,
                hourLabel = hourLabel,
                currentStopTitle = "Nessuna tappa programmata oggi",
                punctualityStatus = "IN ORARIO",
                delayMinutes = 0,
                abacusRecommendation = "Abacus Engine: Giornata libera o di arrivo. Risorse e budget intatti.",
                efficiencyScore = 100
            )
        }

        // Identify current or next stop
        val currentStop = dayStops.firstOrNull { !it.isCompleted } ?: dayStops.last()
        val delay = simulatedDelayMinutes

        val (punctuality, recommendation, score) = when {
            delay > 30 -> Triple(
                "RITARDO ELEVATO (+${delay}m)",
                "Abacus Audit: Rilevato scostamento orario critico (+${delay}m) su '${currentStop.title}'. Suggerita ricalibrazione: comprimere la prossima sosta di 20 min o spostare l'ultima tappa serale per salvaguardare il programma.",
                78
            )
            delay > 10 -> Triple(
                "RITARDO LIEVE (+${delay}m)",
                "Abacus Audit: Ritardo lieve di ${delay} min rilevato rispetto alla tabella di marcia. Tempistica recuperabile anticipando lo spostamento alla fermata successiva.",
                89
            )
            delay < -10 -> Triple(
                "ANTICIPATO (${-delay}m)",
                "Abacus Audit: Sei in anticipo di ${-delay} min! Tempo extra disponibile per una passeggiata panoramica o relax prima della tappa '${currentStop.title}'.",
                100
            )
            else -> Triple(
                "PERFETTAMENTE IN ORARIO",
                "Abacus Audit: Tempistiche ottimali verificate. Tappa attuale '${currentStop.title}' in linea con la pianificazione di Gemini. Prossimo spostamento fluido.",
                98
            )
        }

        return HourlyCheckRecord(
            tripId = trip.id,
            timestamp = System.currentTimeMillis(),
            hourLabel = hourLabel,
            currentStopTitle = currentStop.title,
            punctualityStatus = punctuality,
            delayMinutes = delay,
            abacusRecommendation = recommendation,
            efficiencyScore = score
        )
    }

    /**
     * Auto-rebalance stops when delay occurs
     */
    fun rebalanceStops(stops: List<TripStop>, delayMinutes: Int): List<TripStop> {
        if (stops.isEmpty() || delayMinutes == 0) return stops

        val rebalanced = stops.toMutableList()
        var currentMinutes = 9 * 60 // Starts at 09:00

        for (i in rebalanced.indices) {
            val stop = rebalanced[i]
            val duration = if (stop.durationMinutes > 90 && delayMinutes > 15) {
                maxOf(60, stop.durationMinutes - 15)
            } else {
                stop.durationMinutes
            }

            val startH = currentMinutes / 60
            val startM = currentMinutes % 60
            val endTotal = currentMinutes + duration
            val endH = endTotal / 60
            val endM = endTotal % 60

            val newTimeSlot = String.format("%02d:%02d - %02d:%02d", startH, startM, endH, endM)
            rebalanced[i] = stop.copy(
                timeSlot = newTimeSlot,
                durationMinutes = duration,
                hourlyStatus = if (stop.isCompleted) "Completato" else "Ricalibrato In Orario"
            )

            currentMinutes = endTotal + 20 // 20m transit buffer
        }
        return rebalanced
    }

    /**
     * Distance in kilometers using Haversine formula
     */
    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
