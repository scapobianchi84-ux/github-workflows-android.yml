package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Trip
import com.example.data.model.TripStop
import com.example.ui.components.InteractiveTripMap
import com.example.ui.components.openGoogleMapsSingleStop

@Composable
fun ItineraryScreen(
    trip: Trip?,
    dayStops: List<TripStop>,
    selectedDay: Int,
    selectedStop: TripStop?,
    onSelectDay: (Int) -> Unit,
    onSelectStop: (TripStop) -> Unit,
    onEditStop: (TripStop) -> Unit,
    onToggleCompleted: (TripStop) -> Unit,
    onAddNewStop: () -> Unit,
    onOpenBookingSheet: () -> Unit,
    onOpenChat: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (trip == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Seleziona o crea una vacanza per visualizzare l'itinerario", color = Color.Gray)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("itinerary_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // Destination title header
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = trip.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = trip.destination,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Open Bookings Sheet button
                    FilledTonalButton(
                        onClick = onOpenBookingSheet,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("open_bookings_button")
                    ) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Prenotazioni", fontSize = 12.sp)
                    }
                }
            }
        }

        // Days selector bar
        item {
            Text(
                text = "Seleziona Giorno di Viaggio",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1D1B20)
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items((1..trip.durationDays).toList()) { day ->
                    val isSelected = day == selectedDay
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectDay(day) },
                        shape = CircleShape,
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color(0xFFF3EDF7),
                            selectedContainerColor = Color(0xFF6750A4),
                            selectedLabelColor = Color.White,
                            labelColor = Color(0xFF1D1B20)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = Color(0xFFCAC4D0),
                            selectedBorderColor = Color(0xFF6750A4)
                        ),
                        label = {
                            Text(
                                text = "Giorno $day",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp)) }
                        } else null
                    )
                }
            }
        }

        // Interactive Google Maps Visual Route
        item {
            InteractiveTripMap(
                stops = dayStops,
                selectedStop = selectedStop,
                onSelectStop = onSelectStop,
                onEditStop = onEditStop
            )
        }

        // AI Trip Guide & Curiosities Quick Access Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                border = BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF6750A4)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChatBubble,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Hai domande o curiosità sul viaggio?",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1D1B20)
                            )
                            Text(
                                text = "La Guida AI conosce tutte le tue tappe e i segreti locali",
                                fontSize = 11.sp,
                                color = Color(0xFF49454F)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onOpenChat,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF6750A4),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("itinerary_open_chat_button")
                    ) {
                        Text("Chiedi all'AI", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Stops header + Add stop button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Tappe di Giorno $selectedDay (${dayStops.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedButton(
                    onClick = onAddNewStop,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_stop_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Aggiungi Tappa", fontSize = 12.sp)
                }
            }
        }

        // Stops list
        if (dayStops.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Nessuna tappa per questo giorno. Aggiungine una!", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(dayStops) { stop ->
                StopCard(
                    stop = stop,
                    isSelected = selectedStop?.id == stop.id,
                    onSelect = { onSelectStop(stop) },
                    onEdit = { onEditStop(stop) },
                    onToggleCompleted = { onToggleCompleted(stop) },
                    onNavigate = { openGoogleMapsSingleStop(context, stop) }
                )
            }
        }
    }
}

@Composable
fun StopCard(
    stop: TripStop,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onToggleCompleted: () -> Unit,
    onNavigate: () -> Unit
) {
    Card(
        onClick = onSelect,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFEADDFF).copy(alpha = 0.45f)
            else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp),
        border = BorderStroke(
            1.dp,
            if (isSelected) Color(0xFF6750A4) else Color(0xFFCAC4D0).copy(alpha = 0.6f)
        ),
        modifier = Modifier.fillMaxWidth().testTag("stop_card_${stop.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    // Number Badge
                    Surface(
                        color = if (stop.isCompleted) Color(0xFF10B981) else Color(0xFF6750A4),
                        shape = CircleShape,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (stop.isCompleted) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            } else {
                                Text(
                                    text = "${stop.orderIndex + 1}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = stop.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1D1B20)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = Color(0xFF6750A4),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stop.timeSlot,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF6750A4)
                            )
                        }
                    }
                }

                // Sleek Category pill tag
                Surface(
                    color = Color(0xFFE8DEF8),
                    shape = CircleShape
                ) {
                    Text(
                        text = stop.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1D192B),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Gemini Curated Description
            Text(
                text = stop.description,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF49454F),
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Cost & Location bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = Color(0xFF21005D),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (stop.estimatedCost > 0) "${stop.estimatedCost}€" else "Gratuito",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF21005D)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "${stop.durationMinutes} min",
                        fontSize = 11.sp,
                        color = Color(0xFF49454F)
                    )
                }

                // Action icons: Navigate, Edit, Complete
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onNavigate,
                        modifier = Modifier.size(34.dp).testTag("stop_navigate_${stop.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Directions,
                            contentDescription = "Naviga con Google Maps",
                            tint = Color(0xFF6750A4),
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(34.dp).testTag("stop_edit_${stop.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Modifica singola fermata",
                            tint = Color(0xFF49454F),
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleCompleted,
                        modifier = Modifier.size(34.dp).testTag("stop_toggle_${stop.id}")
                    ) {
                        Icon(
                            imageVector = if (stop.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Stato visita",
                            tint = if (stop.isCompleted) Color(0xFF10B981) else Color(0xFFCAC4D0),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
