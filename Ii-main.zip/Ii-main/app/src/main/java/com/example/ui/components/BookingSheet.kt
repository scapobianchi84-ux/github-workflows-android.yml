package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingOption
import com.example.data.model.Trip
import com.example.data.model.TripStop

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingSheet(
    trip: Trip,
    stops: List<TripStop>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val destEncoded = Uri.encode(trip.destination)

    val bookingIntegrations = listOf(
        BookingOption(
            title = "Alloggi & Hotel a ${trip.destination}",
            provider = "Booking.com Real-Time",
            category = "Alloggi",
            priceEstimate = "da 65€ / notte",
            url = "https://www.booking.com/searchresults.it.html?ss=$destEncoded"
        ),
        BookingOption(
            title = "Voli & Trasporti per ${trip.destination}",
            provider = "Google Flights / Skyscanner",
            category = "Voli/Treni",
            priceEstimate = "Miglior tariffa garantita",
            url = "https://www.google.com/travel/flights?q=flights+to+$destEncoded"
        ),
        BookingOption(
            title = "Biglietti Salta-Fila Attrazioni",
            provider = "GetYourGuide & Tiqets",
            category = "Biglietti & Tour",
            priceEstimate = "Tariffe ufficiali con accesso rapido",
            url = "https://www.getyourguide.it/s/?q=$destEncoded"
        ),
        BookingOption(
            title = "Tavoli nei Ristoranti Tipici",
            provider = "TheFork Live Reservations",
            category = "Ristoranti",
            priceEstimate = "Sconti fino al -30% alla cassa",
            url = "https://www.thefork.it"
        )
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = Color(0xFFFEF7FF)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
                .testTag("booking_sheet")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Sistemi di Prenotazione Live",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1D1B20)
                    )
                    Text(
                        text = "Integrazione in tempo reale con fornitori verificati",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = Color(0xFF49454F)
                    )
                }

                Surface(
                    color = Color(0xFFEADDFF),
                    shape = CircleShape
                ) {
                    Text(
                        text = "API Live",
                        color = Color(0xFF21005D),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Booking items
            bookingIntegrations.forEach { item ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFF3EDF7)
                    ),
                    border = BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clickable { openWebUrl(context, item.url) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFD0BCFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            val icon = when (item.category) {
                                "Alloggi" -> Icons.Default.Hotel
                                "Voli/Treni" -> Icons.Default.Flight
                                "Biglietti & Tour" -> Icons.Default.ConfirmationNumber
                                else -> Icons.Default.Restaurant
                            }
                            Icon(icon, contentDescription = null, tint = Color(0xFF21005D))
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1D1B20)
                            )
                            Text(
                                text = "${item.provider} • ${item.priceEstimate}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = Color(0xFF49454F)
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Apri",
                            tint = Color(0xFF6750A4),
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Specific stops tickets quick list
            val ticketStops = stops.filter { it.estimatedCost > 0 || !it.bookingUrl.isNullOrEmpty() }
            if (ticketStops.isNotEmpty()) {
                Text(
                    text = "Biglietti Specifici per le Tue Tappe",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                ticketStops.forEach { stop ->
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                val url = stop.bookingUrl ?: "https://www.getyourguide.it/s/?q=${Uri.encode(stop.title)}"
                                openWebUrl(context, url)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stop.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("${stop.estimatedCost}€ stimati da Abacus", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            FilledTonalButton(
                                onClick = {
                                    val url = stop.bookingUrl ?: "https://www.getyourguide.it/s/?q=${Uri.encode(stop.title)}"
                                    openWebUrl(context, url)
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Prenota", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

fun openWebUrl(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback
    }
}
