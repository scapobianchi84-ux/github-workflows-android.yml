package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// "Sleek Interface" Theme Colors
val SleekBgLight = Color(0xFFFEF7FF)
val SleekSurfaceLight = Color(0xFFFFFFFF)
val SleekSurfaceVariant = Color(0xFFF3EDF7)
val SleekTextPrimary = Color(0xFF1D1B20)
val SleekTextSecondary = Color(0xFF49454F)

val SleekPrimary = Color(0xFF6750A4)
val SleekOnPrimary = Color(0xFFFFFFFF)
val SleekPrimaryContainer = Color(0xFFEADDFF)
val SleekOnPrimaryContainer = Color(0xFF21005D)

val SleekSecondary = Color(0xFF625B71)
val SleekSecondaryContainer = Color(0xFFE8DEF8)
val SleekOnSecondaryContainer = Color(0xFF1D192B)

val SleekPillBlue = Color(0xFFD3E3FD)
val SleekPillBlueText = Color(0xFF041E49)
val SleekBadgePurple = Color(0xFFD0BCFF)

val SleekBorder = Color(0xFFCAC4D0)
val SleekBorderSubtle = Color(0xFFE8DEF8)
val SleekGreen = Color(0xFF10B981)

// Dark Palette Variants
val SleekBgDark = Color(0xFF141218)
val SleekSurfaceDark = Color(0xFF2B2930)
val SleekSurfaceVariantDark = Color(0xFF49454F)
val SleekTextPrimaryDark = Color(0xFFE6E0E9)
val SleekTextSecondaryDark = Color(0xFFCAC4D0)
val SleekPrimaryDark = Color(0xFFD0BCFF)


