package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TripStop

@Composable
fun StopEditDialog(
    stop: TripStop,
    onDismiss: () -> Unit,
    onSave: (TripStop) -> Unit,
    onDelete: (TripStop) -> Unit
) {
    var title by remember { mutableStateOf(stop.title) }
    var timeSlot by remember { mutableStateOf(stop.timeSlot) }
    var category by remember { mutableStateOf(stop.category) }
    var description by remember { mutableStateOf(stop.description) }
    var costStr by remember { mutableStateOf(stop.estimatedCost.toString()) }
    var durationMinutesStr by remember { mutableStateOf(stop.durationMinutes.toString()) }
    var address by remember { mutableStateOf(stop.addressOrLocation) }
    var isCompleted by remember { mutableStateOf(stop.isCompleted) }

    val categories = listOf("Cultura", "Cibo", "Relax", "Attività", "Natura", "Trasporto")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("stop_edit_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Modifica Fermata / Tappa",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Personalizza orario, spesa stimata e dettagli della tappa",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nome Tappa / Attrazione") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("stop_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category selection
                Text(
                    text = "Categoria",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Time slot & Duration
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = timeSlot,
                        onValueChange = { timeSlot = it },
                        label = { Text("Fascia Oraria") },
                        placeholder = { Text("09:30 - 11:00") },
                        modifier = Modifier.weight(1f).testTag("stop_timeslot_input")
                    )
                    OutlinedTextField(
                        value = durationMinutesStr,
                        onValueChange = { durationMinutesStr = it },
                        label = { Text("Durata (min)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Cost & Address
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = costStr,
                        onValueChange = { costStr = it },
                        label = { Text("Costo Stimato (€)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f).testTag("stop_cost_input")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Indirizzo / Luogo su Mappa") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Note & Consigli AI") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Completed toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Segna come visitata",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = isCompleted,
                        onCheckedChange = { isCompleted = it }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = { onDelete(stop) },
                        colors = IconButtonDefaults.iconButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.testTag("delete_stop_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Elimina tappa")
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = onDismiss) {
                            Text("Annulla")
                        }
                        Button(
                            onClick = {
                                val parsedCost = costStr.toDoubleOrNull() ?: stop.estimatedCost
                                val parsedDur = durationMinutesStr.toIntOrNull() ?: stop.durationMinutes
                                onSave(
                                    stop.copy(
                                        title = title.ifBlank { stop.title },
                                        timeSlot = timeSlot.ifBlank { stop.timeSlot },
                                        category = category,
                                        description = description,
                                        estimatedCost = parsedCost,
                                        durationMinutes = parsedDur,
                                        addressOrLocation = address,
                                        isCompleted = isCompleted
                                    )
                                )
                            },
                            modifier = Modifier.testTag("save_stop_button")
                        ) {
                            Text("Salva Modifiche")
                        }
                    }
                }
            }
        }
    }
}
