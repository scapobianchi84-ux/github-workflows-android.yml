package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TripStop

@Composable
fun InteractiveTripMap(
    stops: List<TripStop>,
    selectedStop: TripStop?,
    onSelectStop: (TripStop) -> Unit,
    onEditStop: (TripStop) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var zoomLevel by remember { mutableStateOf(1f) }

    val primaryColor = Color(0xFF6750A4)
    val secondaryColor = Color(0xFFD0BCFF)
    val surfaceColor = Color(0xFFF3EDF7)
    val borderColor = Color(0xFFCAC4D0)
    val borderSubtle = Color(0xFFE8DEF8)

    val currentDisplayStop = selectedStop ?: stops.firstOrNull()
    val nextStop = if (currentDisplayStop != null && stops.size > 1) {
        val idx = stops.indexOfFirst { it.id == currentDisplayStop.id }
        if (idx >= 0 && idx < stops.size - 1) stops[idx + 1] else stops.firstOrNull { it.id != currentDisplayStop.id }
    } else null

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("interactive_trip_map_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = surfaceColor),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.8f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            // Sleek Map View Container with Canvas and Overlays
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(surfaceColor)
                    .border(1.dp, borderSubtle, RoundedCornerShape(20.dp))
            ) {
                if (stops.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Nessuna tappa presente per oggi", color = Color(0xFF49454F), fontSize = 13.sp)
                    }
                } else {
                    // Coordinate normalization
                    val minLat = stops.minOfOrNull { it.latitude } ?: 0.0
                    val maxLat = stops.maxOfOrNull { it.latitude } ?: 1.0
                    val minLon = stops.minOfOrNull { it.longitude } ?: 0.0
                    val maxLon = stops.maxOfOrNull { it.longitude } ?: 1.0

                    val latSpan = maxOf(0.005, maxLat - minLat)
                    val lonSpan = maxOf(0.005, maxLon - minLon)

                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(stops) {
                                detectTapGestures { offset ->
                                    val canvasW = size.width
                                    val canvasH = size.height
                                    val pad = 44f

                                    // Find closest stop
                                    var closestStop: TripStop? = null
                                    var minDist = Float.MAX_VALUE

                                    stops.forEach { stop ->
                                        val normX = ((stop.longitude - minLon) / lonSpan).toFloat()
                                        val normY = (1f - ((stop.latitude - minLat) / latSpan).toFloat())

                                        val ptX = pad + normX * (canvasW - 2 * pad)
                                        val ptY = pad + normY * (canvasH - 2 * pad)

                                        val dist = (offset.x - ptX) * (offset.x - ptX) + (offset.y - ptY) * (offset.y - ptY)
                                        if (dist < 3000f && dist < minDist) {
                                            minDist = dist
                                            closestStop = stop
                                        }
                                    }
                                    closestStop?.let { onSelectStop(it) }
                                }
                            }
                    ) {
                        val canvasW = size.width
                        val canvasH = size.height
                        val pad = 44f

                        // Draw Sleek dot-matrix texture (radial-gradient effect)
                        val dotStep = 22.dp.toPx()
                        var dotY = dotStep / 2
                        while (dotY < canvasH) {
                            var dotX = dotStep / 2
                            while (dotX < canvasW) {
                                drawCircle(
                                    color = primaryColor.copy(alpha = 0.12f),
                                    radius = 1.6f,
                                    center = Offset(dotX, dotY)
                                )
                                dotX += dotStep
                            }
                            dotY += dotStep
                        }

                        // Calculate pixel points
                        val points = stops.map { stop ->
                            val normX = ((stop.longitude - minLon) / lonSpan).toFloat()
                            val normY = (1f - ((stop.latitude - minLat) / latSpan).toFloat())
                            Offset(
                                x = pad + normX * (canvasW - 2 * pad),
                                y = pad + normY * (canvasH - 2 * pad)
                            )
                        }

                        // Draw Sleek purple path connecting stops in order
                        if (points.size > 1) {
                            val routePath = Path().apply {
                                moveTo(points[0].x, points[0].y)
                                for (i in 1 until points.size) {
                                    lineTo(points[i].x, points[i].y)
                                }
                            }
                            drawPath(
                                path = routePath,
                                color = primaryColor,
                                style = Stroke(
                                    width = 4f,
                                    cap = StrokeCap.Round,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f)
                                )
                            )
                        }

                        // Draw stop markers
                        points.forEachIndexed { index, pt ->
                            val stop = stops[index]
                            val isSelected = (selectedStop?.id == stop.id) || (selectedStop == null && index == 0)

                            if (isSelected) {
                                drawCircle(
                                    color = secondaryColor.copy(alpha = 0.45f),
                                    radius = 24f,
                                    center = pt
                                )
                            }

                            drawCircle(
                                color = if (isSelected) primaryColor else Color(0xFF625B71),
                                radius = if (isSelected) 13f else 9f,
                                center = pt
                            )
                            drawCircle(
                                color = Color.White,
                                radius = if (isSelected) 5f else 3.5f,
                                center = pt
                            )
                        }
                    }

                    // Floating Top Overlay Card: Current Stop + Weather
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(10.dp)
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.95f),
                        border = BorderStroke(1.dp, borderSubtle),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(secondaryColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = Color(0xFF21005D),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "TAPPA CORRENTE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF49454F),
                                        letterSpacing = 0.8.sp
                                    )
                                    Text(
                                        text = currentDisplayStop?.title ?: "Inizia Viaggio",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF1D1B20),
                                        maxLines = 1
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Meteo",
                                    fontSize = 9.sp,
                                    color = Color(0xFF49454F)
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = "22°C",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF1D1B20)
                                    )
                                    Icon(
                                        imageVector = Icons.Default.WbSunny,
                                        contentDescription = null,
                                        tint = Color(0xFFF59E0B),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Floating Bottom Overlay Card: Optimized Route + Next Stop info
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(10.dp)
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.95f),
                        border = BorderStroke(1.dp, borderSubtle),
                        shadowElevation = 3.dp
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Percorso Ottimizzato",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1D1B20)
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF10B981))
                                    )
                                    Text(
                                        text = "MONITORAGGIO ATTIVO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryColor,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(
                                            width = 0.dp,
                                            color = Color.Transparent
                                        )
                                ) {
                                    Text(
                                        text = "Prossima: ${nextStop?.title ?: (stops.lastOrNull()?.title ?: "Destinazione")}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF1D1B20),
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${nextStop?.durationMinutes ?: 15} min • A piedi / Taxi",
                                        fontSize = 10.sp,
                                        color = Color(0xFF49454F)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .width(1.dp)
                                        .height(26.dp)
                                        .background(borderColor)
                                )

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Check-in Programmato",
                                        fontSize = 10.sp,
                                        color = Color(0xFF49454F)
                                    )
                                    Text(
                                        text = currentDisplayStop?.timeSlot ?: "14:00 • Inizio",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF1D1B20)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sleek Dual Action Buttons from the Design Theme:
            // 1. Primary: Modify / Open Maps
            // 2. Secondary: AI Re-Sync / Edit Stop
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { openGoogleMapsFullRoute(context, stops) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("open_google_maps_route_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = primaryColor,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Directions,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Google Maps", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        currentDisplayStop?.let { onEditStop(it) }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("edit_selected_stop_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE8DEF8),
                        contentColor = Color(0xFF1D192B)
                    ),
                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = Color(0xFF1D192B)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Modifica Tappa", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

fun openGoogleMapsFullRoute(context: Context, stops: List<TripStop>) {
    if (stops.isEmpty()) return
    try {
        val origin = Uri.encode(stops.first().addressOrLocation.ifBlank { "${stops.first().latitude},${stops.first().longitude}" })
        val destination = Uri.encode(stops.last().addressOrLocation.ifBlank { "${stops.last().latitude},${stops.last().longitude}" })

        val waypoints = if (stops.size > 2) {
            stops.subList(1, stops.size - 1)
                .joinToString("|") { Uri.encode(it.addressOrLocation.ifBlank { "${it.latitude},${it.longitude}" }) }
        } else ""

        val url = if (waypoints.isNotEmpty()) {
            "https://www.google.com/maps/dir/?api=1&origin=$origin&destination=$destination&waypoints=$waypoints&travelmode=walking"
        } else {
            "https://www.google.com/maps/dir/?api=1&origin=$origin&destination=$destination&travelmode=walking"
        }

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to simple maps search
        val query = Uri.encode(stops.first().title)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$query"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }
}

fun openGoogleMapsSingleStop(context: Context, stop: TripStop) {
    try {
        val query = Uri.encode(stop.addressOrLocation.ifBlank { stop.title })
        val geoUri = Uri.parse("geo:${stop.latitude},${stop.longitude}?q=$query")
        val mapIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(mapIntent)
    } catch (e: Exception) {
        val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(stop.title)}")
        val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(webIntent)
    }
}
