package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Trip
import com.example.data.model.TripStop
import com.example.data.model.WeatherForecastDay
import com.example.domain.AbacusOptimizer
import com.example.ui.components.WeatherWidget
import com.example.ui.components.openWebUrl

@Composable
fun AnalyticsWeatherScreen(
    trip: Trip?,
    allStops: List<TripStop>,
    weatherForecast: List<WeatherForecastDay>,
    onOpenBookingSheet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (trip == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Seleziona una vacanza per visualizzare costi, durata e meteo", color = Color.Gray)
        }
        return
    }

    val budgetBreakdown = AbacusOptimizer.calculateBudgetBreakdown(
        totalBudget = trip.budgetTotal,
        durationDays = trip.durationDays,
        stops = allStops
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("analytics_weather_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // Title & Destination
        item {
            Column {
                Text(
                    text = "Meteo, Costi & Risorse",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Analisi integrata per ${trip.destination}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live Weather Widget
        item {
            WeatherWidget(
                destination = trip.destination,
                forecast = weatherForecast
            )
        }

        // Cost & Budget Overview Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.6f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth().testTag("budget_analytics_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFD0BCFF)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color(0xFF21005D),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Ottimizzazione Costi Abacus",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1D1B20)
                                )
                                Text(
                                    text = "Ripartizione calcolata sul tuo budget",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = Color(0xFF49454F)
                                )
                            }
                        }

                        Text(
                            text = "${trip.budgetTotal.toInt()}€",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF21005D)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress bar
                    val progress = (budgetBreakdown.totalEstimated / maxOf(1.0, budgetBreakdown.budgetTotal)).toFloat()
                    LinearProgressIndicator(
                        progress = { minOf(1f, progress) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = Color(0xFF6750A4),
                        trackColor = Color(0xFFE8DEF8)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Totale Stimato: ${budgetBreakdown.totalEstimated.toInt()}€",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1D1B20)
                        )
                        Text(
                            text = if (budgetBreakdown.isUnderBudget) "Rimanenti: ${budgetBreakdown.remainingBudget.toInt()}€" else "Fuori budget",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (budgetBreakdown.isUnderBudget) Color(0xFF10B981) else Color(0xFFB3261E)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Breakdown items
                    BudgetCategoryRow("Alloggi & Hotel (stimati)", budgetBreakdown.accommodationCost, Icons.Default.Hotel)
                    BudgetCategoryRow("Cibo & Trattorie tipiche", budgetBreakdown.foodCost, Icons.Default.Restaurant)
                    BudgetCategoryRow("Musei, Biglietti & Tour", budgetBreakdown.activitiesCost, Icons.Default.ConfirmationNumber)
                    BudgetCategoryRow("Trasporti urbani / Treni", budgetBreakdown.transportCost, Icons.Default.DirectionsBus)
                    BudgetCategoryRow("Buffer Emergenze / Extra", budgetBreakdown.bufferEmergencyCost, Icons.Default.Shield)
                }
            }
        }

        // Duration & Pacing Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.6f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth().testTag("duration_pacing_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Durata & Ritmo di Viaggio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1D1B20)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFFF3EDF7),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Durata Totale", fontSize = 11.sp, color = Color(0xFF49454F))
                                Text("${trip.durationDays} Giorni", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1D1B20))
                            }
                        }

                        Surface(
                            color = Color(0xFFF3EDF7),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Tappe Totali", fontSize = 11.sp, color = Color(0xFF49454F))
                                Text("${allStops.size} Fermate", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1D1B20))
                            }
                        }

                        Surface(
                            color = Color(0xFFF3EDF7),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Media Giornaliera", fontSize = 11.sp, color = Color(0xFF49454F))
                                val avg = if (trip.durationDays > 0) (trip.budgetTotal / trip.durationDays).toInt() else 0
                                Text("${avg}€/giorno", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1D1B20))
                            }
                        }
                    }
                }
            }
        }

        // Direct Booking Integration Quick Launch
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEADDFF)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sistemi di Prenotazione Live",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF21005D)
                            )
                            Text(
                                text = "Booking, Skyscanner, GetYourGuide, TheFork",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = Color(0xFF49454F)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = onOpenBookingSheet,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF6750A4),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.testTag("analytics_booking_button")
                        ) {
                            Text("Apri Portali", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BudgetCategoryRow(title: String, amount: Double, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        Text(
            text = "${amount.toInt()}€",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
