package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.HourlyCheckRecord
import com.example.data.model.Trip
import com.example.data.model.TripStop
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {

    @Query("SELECT * FROM trips ORDER BY id DESC")
    fun getAllTrips(): Flow<List<Trip>>

    @Query("SELECT * FROM trips WHERE id = :tripId LIMIT 1")
    fun getTripById(tripId: Long): Flow<Trip?>

    @Query("SELECT * FROM trips WHERE id = :tripId LIMIT 1")
    suspend fun getTripByIdSync(tripId: Long): Trip?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: Trip): Long

    @Update
    suspend fun updateTrip(trip: Trip)

    @Delete
    suspend fun deleteTrip(trip: Trip)

    // STOPS
    @Query("SELECT * FROM trip_stops WHERE tripId = :tripId ORDER BY dayNumber ASC, orderIndex ASC")
    fun getStopsForTrip(tripId: Long): Flow<List<TripStop>>

    @Query("SELECT * FROM trip_stops WHERE tripId = :tripId AND dayNumber = :dayNumber ORDER BY orderIndex ASC")
    fun getStopsForDay(tripId: Long, dayNumber: Int): Flow<List<TripStop>>

    @Query("SELECT * FROM trip_stops WHERE tripId = :tripId AND dayNumber = :dayNumber ORDER BY orderIndex ASC")
    suspend fun getStopsForDaySync(tripId: Long, dayNumber: Int): List<TripStop>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStop(stop: TripStop): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStops(stops: List<TripStop>)

    @Update
    suspend fun updateStop(stop: TripStop)

    @Delete
    suspend fun deleteStop(stop: TripStop)

    @Query("DELETE FROM trip_stops WHERE id = :stopId")
    suspend fun deleteStopById(stopId: Long)

    // HOURLY CHECKS
    @Query("SELECT * FROM hourly_checks WHERE tripId = :tripId ORDER BY timestamp DESC")
    fun getHourlyChecksForTrip(tripId: Long): Flow<List<HourlyCheckRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHourlyCheck(check: HourlyCheckRecord): Long

    @Query("DELETE FROM hourly_checks WHERE tripId = :tripId")
    suspend fun clearHourlyChecksForTrip(tripId: Long)
}
