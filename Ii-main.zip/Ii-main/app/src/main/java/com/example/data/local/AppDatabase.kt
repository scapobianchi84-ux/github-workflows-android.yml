package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.HourlyCheckRecord
import com.example.data.model.Trip
import com.example.data.model.TripStop
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Trip::class, TripStop::class, HourlyCheckRecord::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vacanza_ai_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.tripDao())
                    }
                }
            }
        }

        private suspend fun populateInitialData(dao: TripDao) {
            // Preload 1st trip: Roma Vacanza Culturale & Gourmet
            val tripId1 = dao.insertTrip(
                Trip(
                    title = "Roma Eterna & Sapori Gourmet",
                    destination = "Roma, Italia",
                    interests = "Arte antica, Musei Vaticani, Cucina tipica romana, Passeggiate nei vicoli",
                    durationDays = 3,
                    startDate = "15 Maggio 2026",
                    budgetTotal = 850.0,
                    budgetSpent = 430.0,
                    latitude = 41.9028,
                    longitude = 12.4964,
                    aiModelSummary = "Gemini 3.5 Flash (Itinerario) + Abacus Engine (Ottimizzazione Costi e Orari)",
                    status = "In Corso",
                    isHourlyTrackingActive = true,
                    currentDay = 1
                )
            )

            val stopsTrip1 = listOf(
                TripStop(
                    tripId = tripId1,
                    dayNumber = 1,
                    orderIndex = 0,
                    timeSlot = "09:00 - 11:30",
                    title = "Colosseo & Fori Imperiali",
                    category = "Cultura",
                    description = "Visita al celebre anfiteatro Flavio con accesso all'arena e passeggiata archeologica sulla via sacra.",
                    estimatedCost = 24.0,
                    durationMinutes = 150,
                    latitude = 41.8902,
                    longitude = 12.4922,
                    addressOrLocation = "Piazza del Colosseo, 1, Roma",
                    isCompleted = true,
                    hourlyStatus = "In orario",
                    bookingStatus = "Prenotato",
                    bookingUrl = "https://www.getyourguide.it/roma-l33/colosseo-fori-imperiali-tc2/"
                ),
                TripStop(
                    tripId = tripId1,
                    dayNumber = 1,
                    orderIndex = 1,
                    timeSlot = "12:00 - 13:30",
                    title = "Pranzo Tipico a Monti (Trattoria)",
                    category = "Cibo",
                    description = "Pausa gourmet con Cacio e Pepe artigianale e carciofo alla romana in uno dei rioni più pittoreschi.",
                    estimatedCost = 28.0,
                    durationMinutes = 90,
                    latitude = 41.8947,
                    longitude = 12.4939,
                    addressOrLocation = "Via Urbana, Rione Monti, Roma",
                    isCompleted = true,
                    hourlyStatus = "In orario",
                    bookingStatus = "Non richiesto",
                    bookingUrl = "https://www.thefork.it/ristoranti/roma-c415144"
                ),
                TripStop(
                    tripId = tripId1,
                    dayNumber = 1,
                    orderIndex = 2,
                    timeSlot = "14:00 - 15:30",
                    title = "Pantheon & Piazza Navona",
                    category = "Cultura",
                    description = "Ammira l'incredibile cupola con oculo del Pantheon e le fontane berniniane di Piazza Navona.",
                    estimatedCost = 5.0,
                    durationMinutes = 90,
                    latitude = 41.8986,
                    longitude = 12.4769,
                    addressOrLocation = "Piazza della Rotonda, Roma",
                    isCompleted = false,
                    hourlyStatus = "In corso",
                    bookingStatus = "Prenotato",
                    bookingUrl = "https://www.tiqets.com/it/roma-attrazioni-c71631/biglietti-per-pantheon-roma-p1019918/"
                ),
                TripStop(
                    tripId = tripId1,
                    dayNumber = 1,
                    orderIndex = 3,
                    timeSlot = "16:00 - 17:30",
                    title = "Fontana di Trevi & Gelato Artigianale",
                    category = "Relax",
                    description = "Lancio della monetina portafortuna e degustazione del miglior gelato al pistacchio di Bronte.",
                    estimatedCost = 7.0,
                    durationMinutes = 90,
                    latitude = 41.9009,
                    longitude = 12.4833,
                    addressOrLocation = "Piazza di Trevi, Roma",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Non richiesto"
                ),
                TripStop(
                    tripId = tripId1,
                    dayNumber = 1,
                    orderIndex = 4,
                    timeSlot = "18:30 - 20:00",
                    title = "Tramonto al Giardino degli Aranci",
                    category = "Attività",
                    description = "Vista mozzafiato sul Tevere e San Pietro illuminata dalla luce dorata del tramonto romano.",
                    estimatedCost = 0.0,
                    durationMinutes = 90,
                    latitude = 41.8856,
                    longitude = 12.4807,
                    addressOrLocation = "Colle Aventino, Roma",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Non richiesto"
                ),
                // Day 2
                TripStop(
                    tripId = tripId1,
                    dayNumber = 2,
                    orderIndex = 0,
                    timeSlot = "09:00 - 13:00",
                    title = "Musei Vaticani & Cappella Sistina",
                    category = "Cultura",
                    description = "Capolavori di Michelangelo, Stanze di Raffaello e la suggestiva scala elicoidale Momo.",
                    estimatedCost = 30.0,
                    durationMinutes = 240,
                    latitude = 41.9065,
                    longitude = 12.4536,
                    addressOrLocation = "Viale Vaticano, Roma",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Da prenotare",
                    bookingUrl = "https://www.getyourguide.it/roma-l33/musei-vaticani-cappella-sistina-tc1/"
                ),
                TripStop(
                    tripId = tripId1,
                    dayNumber = 2,
                    orderIndex = 1,
                    timeSlot = "13:30 - 15:00",
                    title = "Pranzo a Borgo Pio & Castel Sant'Angelo",
                    category = "Cibo",
                    description = "Spuntino con pinsa romana croccante e passeggiata sul celebre Ponte degli Angeli.",
                    estimatedCost = 18.0,
                    durationMinutes = 90,
                    latitude = 41.9031,
                    longitude = 12.4663,
                    addressOrLocation = "Borgo Pio, Roma",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Non richiesto"
                ),
                TripStop(
                    tripId = tripId1,
                    dayNumber = 2,
                    orderIndex = 2,
                    timeSlot = "16:00 - 18:30",
                    title = "Piazza di Spagna & Trinità dei Monti",
                    category = "Relax",
                    description = "Scalinata monumentale, vista panoramica sulla città e shopping nelle boutique storiche.",
                    estimatedCost = 0.0,
                    durationMinutes = 150,
                    latitude = 41.9060,
                    longitude = 12.4828,
                    addressOrLocation = "Piazza di Spagna, Roma",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Non richiesto"
                )
            )
            dao.insertStops(stopsTrip1)

            // Hourly check sample for trip 1
            dao.insertHourlyCheck(
                HourlyCheckRecord(
                    tripId = tripId1,
                    timestamp = System.currentTimeMillis() - 3600000,
                    hourLabel = "Ore 13:00",
                    currentStopTitle = "Pranzo Tipico a Monti",
                    punctualityStatus = "IN ORARIO",
                    delayMinutes = 0,
                    abacusRecommendation = "Abacus Engine: Tempistiche perfettamente allineate. Prossima tappa Pantheon a 15 minuti a piedi.",
                    efficiencyScore = 99
                )
            )
            dao.insertHourlyCheck(
                HourlyCheckRecord(
                    tripId = tripId1,
                    timestamp = System.currentTimeMillis(),
                    hourLabel = "Ore 14:00",
                    currentStopTitle = "Pantheon & Piazza Navona",
                    punctualityStatus = "IN ORARIO",
                    delayMinutes = 0,
                    abacusRecommendation = "Abacus Engine: Accesso Pantheon alle 14:15. Monitoraggio meteo attivo: sereno 24°C.",
                    efficiencyScore = 98
                )
            )

            // Preload 2nd trip: Barcellona Creativa
            val tripId2 = dao.insertTrip(
                Trip(
                    title = "Barcellona: Gaudì & Tapas sul Mare",
                    destination = "Barcellona, Spagna",
                    interests = "Architettura Modernista, Spiaggia Barceloneta, Mercati locali",
                    durationDays = 4,
                    startDate = "20 Giugno 2026",
                    budgetTotal = 1100.0,
                    budgetSpent = 250.0,
                    latitude = 41.3851,
                    longitude = 2.1734,
                    aiModelSummary = "Gemini 3.5 Flash + Abacus Resource Optimizer",
                    status = "Pianificato",
                    isHourlyTrackingActive = true,
                    currentDay = 1
                )
            )

            val stopsTrip2 = listOf(
                TripStop(
                    tripId = tripId2,
                    dayNumber = 1,
                    orderIndex = 0,
                    timeSlot = "10:00 - 12:30",
                    title = "Sagrada Família con Torri",
                    category = "Cultura",
                    description = "Il capolavoro incompiuto di Antoni Gaudì con luce attraverso le vetrate policrome.",
                    estimatedCost = 36.0,
                    durationMinutes = 150,
                    latitude = 41.4036,
                    longitude = 2.1744,
                    addressOrLocation = "Carrer de Mallorca, 401, Barcellona",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Da prenotare",
                    bookingUrl = "https://www.getyourguide.it/barcellona-l45/sagrada-familia-tc3/"
                ),
                TripStop(
                    tripId = tripId2,
                    dayNumber = 1,
                    orderIndex = 1,
                    timeSlot = "13:00 - 14:30",
                    title = "Pranzo al Mercato de la Boqueria",
                    category = "Cibo",
                    description = "Pintxos, jamón ibérico e macedonia di frutta tropicale freschissima.",
                    estimatedCost = 22.0,
                    durationMinutes = 90,
                    latitude = 41.3817,
                    longitude = 2.1716,
                    addressOrLocation = "La Rambla, 91, Barcellona",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Non richiesto"
                ),
                TripStop(
                    tripId = tripId2,
                    dayNumber = 1,
                    orderIndex = 2,
                    timeSlot = "15:30 - 18:00",
                    title = "Parc Güell & Vista sulla Città",
                    category = "Relax",
                    description = "Panche a serpente in mosaico trencadís e vista spettacolare fino al Mediterraneo.",
                    estimatedCost = 14.0,
                    durationMinutes = 150,
                    latitude = 41.4145,
                    longitude = 2.1527,
                    addressOrLocation = "Gràcia, Barcellona",
                    isCompleted = false,
                    hourlyStatus = "In orario",
                    bookingStatus = "Da prenotare",
                    bookingUrl = "https://www.tiqets.com/it/barcellona-attrazioni-c66342/biglietti-per-parc-gueell-p975549/"
                )
            )
            dao.insertStops(stopsTrip2)
        }
    }
}
