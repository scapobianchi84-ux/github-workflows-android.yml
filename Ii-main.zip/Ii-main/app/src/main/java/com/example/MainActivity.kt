package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TripStop
import com.example.ui.TripViewModel
import com.example.ui.components.AddStopDialog
import com.example.ui.components.BookingSheet
import com.example.ui.components.CreateTripDialog
import com.example.ui.components.StopEditDialog
import com.example.ui.screens.AnalyticsWeatherScreen
import com.example.ui.screens.HourlyMonitorScreen
import com.example.ui.screens.ItineraryScreen
import com.example.ui.screens.TripChatScreen
import com.example.ui.screens.TripListScreen
import com.example.ui.theme.MyApplicationTheme

enum class MainTab(val label: String, val icon: ImageVector) {
    TRIPS("Viaggi", Icons.Default.Luggage),
    ITINERARY("Itinerario", Icons.Default.Map),
    CHAT("Chat AI", Icons.Default.ChatBubble),
    GUARDIAN("Controllo", Icons.Default.Speed),
    RESOURCES("Meteo & Costi", Icons.Default.Analytics)
}

class MainActivity : ComponentActivity() {

    private val viewModel: TripViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val trips by viewModel.trips.collectAsStateWithLifecycle()
                val activeTrip by viewModel.activeTrip.collectAsStateWithLifecycle()
                val allStops by viewModel.stops.collectAsStateWithLifecycle()
                val dayStops by viewModel.dayStops.collectAsStateWithLifecycle()
                val selectedDay by viewModel.selectedDay.collectAsStateWithLifecycle()
                val selectedStop by viewModel.selectedStop.collectAsStateWithLifecycle()
                val hourlyChecks by viewModel.hourlyChecks.collectAsStateWithLifecycle()
                val weatherForecast by viewModel.weatherForecast.collectAsStateWithLifecycle()
                val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
                val simulatedDelay by viewModel.simulatedDelay.collectAsStateWithLifecycle()
                val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
                val isChatResponding by viewModel.isChatResponding.collectAsStateWithLifecycle()

                var currentTab by remember { mutableStateOf(MainTab.TRIPS) }
                var showCreateDialog by remember { mutableStateOf(false) }
                var stopToEdit by remember { mutableStateOf<TripStop?>(null) }
                var showAddStopDialog by remember { mutableStateOf(false) }
                var showBookingSheet by remember { mutableStateOf(false) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing,
                    topBar = {
                        Surface(
                            color = MaterialTheme.colorScheme.background,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                                // Sleek Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // Circular avatar/icon: w-10 h-10 bg-[#6750A4] rounded-full flex items-center justify-center text-white
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF6750A4)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = activeTrip?.title ?: "Vacanza AI",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF1D1B20)
                                            )
                                            Text(
                                                text = "Gemini & Abacus Optimization Active",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontSize = 11.sp,
                                                color = Color(0xFF49454F)
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        IconButton(
                                            onClick = { showCreateDialog = true },
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE8DEF8))
                                                .testTag("topbar_add_trip")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "Nuovo Viaggio",
                                                tint = Color(0xFF49454F),
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }
                                        IconButton(
                                            onClick = { showBookingSheet = true },
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE8DEF8))
                                                .testTag("topbar_booking_sheet")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ShoppingBag,
                                                contentDescription = "Prenotazioni",
                                                tint = Color(0xFF49454F),
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }
                                        IconButton(
                                            onClick = { currentTab = MainTab.CHAT },
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(if (currentTab == MainTab.CHAT) Color(0xFFD0BCFF) else Color(0xFFE8DEF8))
                                                .testTag("topbar_chat_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ChatBubble,
                                                contentDescription = "Chat Guida AI",
                                                tint = if (currentTab == MainTab.CHAT) Color(0xFF21005D) else Color(0xFF49454F),
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }
                                    }
                                }

                                // Sleek Subheader Status Pills Row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(horizontal = 16.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Pill 1: Payments / Budget
                                    val currentTotal = activeTrip?.budgetTotal?.toInt() ?: 2000
                                    val currentEstimated = activeTrip?.let { (it.budgetTotal * 0.85).toInt() } ?: 1850
                                    Surface(
                                        color = Color(0xFFEADDFF),
                                        shape = CircleShape
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Payments,
                                                contentDescription = null,
                                                tint = Color(0xFF21005D),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "€$currentEstimated / €$currentTotal",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = Color(0xFF21005D)
                                            )
                                        }
                                    }

                                    // Pill 2: Duration in Days
                                    Surface(
                                        color = Color(0xFFE8DEF8),
                                        shape = CircleShape
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CalendarToday,
                                                contentDescription = null,
                                                tint = Color(0xFF1D192B),
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = "${activeTrip?.durationDays ?: 7} Days",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = Color(0xFF1D192B)
                                            )
                                        }
                                    }

                                    // Pill 3: Live Sync / Monitoring
                                    Surface(
                                        color = Color(0xFFD3E3FD),
                                        shape = CircleShape
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Speed,
                                                contentDescription = null,
                                                tint = Color(0xFF041E49),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "Live Sync",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = Color(0xFF041E49)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                HorizontalDivider(color = Color(0xFFCAC4D0).copy(alpha = 0.5f), thickness = 0.8.dp)
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color(0xFFF3EDF7),
                            tonalElevation = 0.dp,
                            modifier = Modifier.border(BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.6f)))
                        ) {
                            MainTab.values().forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = tab.icon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.label,
                                            fontSize = 10.sp,
                                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF1D1B20),
                                        selectedTextColor = Color(0xFF1D1B20),
                                        indicatorColor = Color(0xFFE8DEF8),
                                        unselectedIconColor = Color(0xFF49454F),
                                        unselectedTextColor = Color(0xFF49454F)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            MainTab.TRIPS -> {
                                TripListScreen(
                                    trips = trips,
                                    activeTrip = activeTrip,
                                    onSelectTrip = { trip ->
                                        viewModel.selectTrip(trip)
                                    },
                                    onOpenCreateDialog = { showCreateDialog = true },
                                    onNavigateToItinerary = { currentTab = MainTab.ITINERARY }
                                )
                            }

                            MainTab.ITINERARY -> {
                                ItineraryScreen(
                                    trip = activeTrip,
                                    dayStops = dayStops,
                                    selectedDay = selectedDay,
                                    selectedStop = selectedStop,
                                    onSelectDay = { viewModel.selectDay(it) },
                                    onSelectStop = { viewModel.selectStop(it) },
                                    onEditStop = { stopToEdit = it },
                                    onToggleCompleted = { viewModel.toggleStopCompleted(it) },
                                    onAddNewStop = { showAddStopDialog = true },
                                    onOpenBookingSheet = { showBookingSheet = true },
                                    onOpenChat = { currentTab = MainTab.CHAT }
                                )
                            }

                            MainTab.CHAT -> {
                                TripChatScreen(
                                    trip = activeTrip,
                                    stops = allStops,
                                    messages = chatMessages,
                                    isResponding = isChatResponding,
                                    onSendMessage = { viewModel.sendChatMessage(it) },
                                    onClearChat = { viewModel.clearChatHistory() }
                                )
                            }

                            MainTab.GUARDIAN -> {
                                HourlyMonitorScreen(
                                    trip = activeTrip,
                                    dayStops = dayStops,
                                    hourlyChecks = hourlyChecks,
                                    simulatedDelayMinutes = simulatedDelay,
                                    onSetSimulatedDelay = { viewModel.setSimulatedDelay(it) },
                                    onTriggerAudit = { viewModel.performHourlyCheck() },
                                    onRebalanceSchedule = { viewModel.rebalanceScheduleWithAbacus() }
                                )
                            }

                            MainTab.RESOURCES -> {
                                AnalyticsWeatherScreen(
                                    trip = activeTrip,
                                    allStops = allStops,
                                    weatherForecast = weatherForecast,
                                    onOpenBookingSheet = { showBookingSheet = true }
                                )
                            }
                        }
                    }
                }

                // Create Trip Wizard Dialog
                if (showCreateDialog) {
                    CreateTripDialog(
                        isGenerating = isGenerating,
                        onDismiss = { showCreateDialog = false },
                        onCreateTrip = { dest, interests, days, budget ->
                            viewModel.createTripWithAi(dest, interests, days, budget)
                            showCreateDialog = false
                            currentTab = MainTab.ITINERARY
                        }
                    )
                }

                // Stop Edit Dialog
                stopToEdit?.let { stop ->
                    StopEditDialog(
                        stop = stop,
                        onDismiss = { stopToEdit = null },
                        onSave = { updated ->
                            viewModel.updateStop(updated)
                            stopToEdit = null
                        },
                        onDelete = { toDelete ->
                            viewModel.deleteStop(toDelete)
                            stopToEdit = null
                        }
                    )
                }

                // Add Stop Dialog
                if (showAddStopDialog && activeTrip != null) {
                    AddStopDialog(
                        dayNumber = selectedDay,
                        onDismiss = { showAddStopDialog = false },
                        onConfirm = { title, timeSlot, cat, cost, dur, desc, addr ->
                            viewModel.addNewStop(
                                tripId = activeTrip!!.id,
                                dayNumber = selectedDay,
                                title = title,
                                timeSlot = timeSlot,
                                category = cat,
                                cost = cost,
                                duration = dur,
                                description = desc,
                                address = addr
                            )
                            showAddStopDialog = false
                        }
                    )
                }

                // Booking Sheet
                if (showBookingSheet && activeTrip != null) {
                    BookingSheet(
                        trip = activeTrip!!,
                        stops = dayStops,
                        onDismiss = { showBookingSheet = false }
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Vacanza AI: Benvenuto $name!", modifier = modifier)
}

