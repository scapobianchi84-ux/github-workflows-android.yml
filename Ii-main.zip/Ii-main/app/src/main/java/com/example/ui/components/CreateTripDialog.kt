package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun CreateTripDialog(
    isGenerating: Boolean,
    onDismiss: () -> Unit,
    onCreateTrip: (destination: String, interests: String, durationDays: Int, budget: Double) -> Unit
) {
    var destination by remember { mutableStateOf("") }
    var selectedInterests by remember { mutableStateOf(setOf("Arte & Cultura", "Cibo Tipico")) }
    var customNotes by remember { mutableStateOf("") }
    var durationDays by remember { mutableIntStateOf(3) }
    var budgetStr by remember { mutableStateOf("900") }

    val popularDestinations = listOf("Roma", "Barcellona", "Parigi", "Tokyo", "Costiera Amalfitana", "Firenze")
    val interestChips = listOf(
        "Arte & Cultura",
        "Cibo Tipico",
        "Mare & Spiaggia",
        "Avventura & Trekking",
        "Vita Notturna",
        "Shopping & Mercati",
        "Relax & Benessere",
        "Foto & Panorami"
    )

    Dialog(
        onDismissRequest = { if (!isGenerating) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .padding(vertical = 16.dp)
                .testTag("create_trip_dialog"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFFEF7FF)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Pianifica Nuova Vacanza",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Gemini AI + Abacus Resource Optimizer",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(onClick = onDismiss, enabled = !isGenerating) {
                        Icon(Icons.Default.Close, contentDescription = "Chiudi")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (isGenerating) {
                    // AI Generation State
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(56.dp),
                                color = MaterialTheme.colorScheme.primary,
                                strokeWidth = 5.dp
                            )
                            Text(
                                text = "Elaborazione Itinerario Ideale in Corso...",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("1. Gemini 3.5: Generazione tappe culturali & culinarie", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("2. Abacus Engine: Bilanciamento budget & tempistiche orarie", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Form Content

                    // 1. Destination
                    Text(
                        text = "1. Dove vuoi andare?",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        placeholder = { Text("es. Roma, Barcellona, Tokyo, Costiera...") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("destination_input")
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    // Quick chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        popularDestinations.take(3).forEach { dest ->
                            SuggestionChip(
                                onClick = { destination = dest },
                                label = { Text(dest, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        popularDestinations.drop(3).forEach { dest ->
                            SuggestionChip(
                                onClick = { destination = dest },
                                label = { Text(dest, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 2. Interests & Tastes
                    Text(
                        text = "2. I tuoi interessi e gusti",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Gemini personalizzerà le attrazioni in base a queste preferenze",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Interest chips flow
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            interestChips.take(3).forEach { interest ->
                                val selected = selectedInterests.contains(interest)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        selectedInterests = if (selected) selectedInterests - interest else selectedInterests + interest
                                    },
                                    label = { Text(interest, fontSize = 11.sp) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            interestChips.subList(3, 6).forEach { interest ->
                                val selected = selectedInterests.contains(interest)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        selectedInterests = if (selected) selectedInterests - interest else selectedInterests + interest
                                    },
                                    label = { Text(interest, fontSize = 11.sp) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            interestChips.drop(6).forEach { interest ->
                                val selected = selectedInterests.contains(interest)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        selectedInterests = if (selected) selectedInterests - interest else selectedInterests + interest
                                    },
                                    label = { Text(interest, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customNotes,
                        onValueChange = { customNotes = it },
                        placeholder = { Text("Note aggiuntive: es. ritmi lenti, tappe panoramiche, cene all'aperto...") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("custom_notes_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3. Duration
                    Text(
                        text = "3. Durata del viaggio: $durationDays giorni",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(2, 3, 4, 5, 7, 10).forEach { days ->
                            FilledTonalButton(
                                onClick = { durationDays = days },
                                colors = if (durationDays == days) {
                                    ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White)
                                } else {
                                    ButtonDefaults.filledTonalButtonColors()
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("${days}g", fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4. Budget Available
                    Text(
                        text = "4. Budget totale disponibile (€)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Abacus ottimizzerà la ripartizione tra alloggio, pasti e biglietti",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = budgetStr,
                        onValueChange = { budgetStr = it },
                        leadingIcon = { Icon(Icons.Default.Euro, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("budget_input")
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Submit button
                    Button(
                        onClick = {
                            val dest = destination.ifBlank { "Roma, Italia" }
                            val fullInterests = (selectedInterests + customNotes).filter { it.isNotBlank() }.joinToString(", ")
                            val budget = budgetStr.toDoubleOrNull() ?: 800.0
                            onCreateTrip(dest, fullInterests, durationDays, budget)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_create_trip_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Genera Itinerario con Gemini & Abacus",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
