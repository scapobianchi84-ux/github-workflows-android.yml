package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class Trip(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val destination: String,
    val interests: String,
    val durationDays: Int,
    val startDate: String,
    val budgetTotal: Double,
    val budgetSpent: Double = 0.0,
    val currency: String = "€",
    val latitude: Double = 41.9028,
    val longitude: Double = 12.4964,
    val aiModelSummary: String = "Gemini 3.5 Flash + Abacus Resource Optimizer",
    val status: String = "Pianificato", // Pianificato, In Corso, Completato
    val isHourlyTrackingActive: Boolean = true,
    val currentDay: Int = 1,
    val lastCheckTimestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "trip_stops",
    foreignKeys = [
        ForeignKey(
            entity = Trip::class,
            parentColumns = ["id"],
            childColumns = ["tripId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tripId")]
)
data class TripStop(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val dayNumber: Int,
    val orderIndex: Int,
    val timeSlot: String, // e.g. "09:30 - 11:30"
    val title: String,
    val category: String, // "Cultura", "Cibo", "Relax", "Attività", "Natura", "Trasporto"
    val description: String,
    val estimatedCost: Double,
    val durationMinutes: Int,
    val latitude: Double,
    val longitude: Double,
    val addressOrLocation: String,
    val isCompleted: Boolean = false,
    val hourlyStatus: String = "In orario", // "In orario", "In ritardo (+15m)", "Anticipato", "In corso"
    val bookingUrl: String? = null,
    val bookingStatus: String = "Non richiesto" // "Non richiesto", "Da prenotare", "Prenotato"
)

@Entity(
    tableName = "hourly_checks",
    foreignKeys = [
        ForeignKey(
            entity = Trip::class,
            parentColumns = ["id"],
            childColumns = ["tripId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tripId")]
)
data class HourlyCheckRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val hourLabel: String, // e.g. "Ore 10:00"
    val currentStopTitle: String,
    val punctualityStatus: String, // "IN ORARIO", "RITARDO LIEVE (+15m)", "RITARDO CRITICO (+35m)", "ANTICIPATO"
    val delayMinutes: Int = 0,
    val abacusRecommendation: String,
    val efficiencyScore: Int = 98 // percent
)

data class WeatherForecastDay(
    val date: String,
    val dayName: String,
    val tempMax: Double,
    val tempMin: Double,
    val condition: String,
    val rainChance: Int,
    val weatherCode: Int,
    val tip: String
)

data class BookingOption(
    val title: String,
    val provider: String,
    val category: String, // "Alloggi", "Voli/Treni", "Biglietti & Tour", "Ristoranti"
    val priceEstimate: String,
    val url: String,
    val isRealTimeDirect: Boolean = true
)

data class AbacusBudgetBreakdown(
    val accommodationCost: Double,
    val foodCost: Double,
    val activitiesCost: Double,
    val transportCost: Double,
    val bufferEmergencyCost: Double,
    val totalEstimated: Double,
    val budgetTotal: Double,
    val remainingBudget: Double,
    val isUnderBudget: Boolean
)
