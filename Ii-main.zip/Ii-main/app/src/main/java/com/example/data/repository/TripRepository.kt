package com.example.data.repository

import com.example.data.local.TripDao
import com.example.data.model.HourlyCheckRecord
import com.example.data.model.Trip
import com.example.data.model.TripStop
import kotlinx.coroutines.flow.Flow

class TripRepository(private val tripDao: TripDao) {

    val allTrips: Flow<List<Trip>> = tripDao.getAllTrips()

    fun getTripById(tripId: Long): Flow<Trip?> = tripDao.getTripById(tripId)

    suspend fun getTripByIdSync(tripId: Long): Trip? = tripDao.getTripByIdSync(tripId)

    fun getStopsForTrip(tripId: Long): Flow<List<TripStop>> = tripDao.getStopsForTrip(tripId)

    fun getStopsForDay(tripId: Long, dayNumber: Int): Flow<List<TripStop>> =
        tripDao.getStopsForDay(tripId, dayNumber)

    suspend fun getStopsForDaySync(tripId: Long, dayNumber: Int): List<TripStop> =
        tripDao.getStopsForDaySync(tripId, dayNumber)

    suspend fun insertTrip(trip: Trip): Long = tripDao.insertTrip(trip)

    suspend fun updateTrip(trip: Trip) = tripDao.updateTrip(trip)

    suspend fun deleteTrip(trip: Trip) = tripDao.deleteTrip(trip)

    suspend fun insertStop(stop: TripStop): Long = tripDao.insertStop(stop)

    suspend fun insertStops(stops: List<TripStop>) = tripDao.insertStops(stops)

    suspend fun updateStop(stop: TripStop) = tripDao.updateStop(stop)

    suspend fun deleteStop(stop: TripStop) = tripDao.deleteStop(stop)

    suspend fun deleteStopById(stopId: Long) = tripDao.deleteStopById(stopId)

    fun getHourlyChecksForTrip(tripId: Long): Flow<List<HourlyCheckRecord>> =
        tripDao.getHourlyChecksForTrip(tripId)

    suspend fun insertHourlyCheck(check: HourlyCheckRecord): Long =
        tripDao.insertHourlyCheck(check)

    suspend fun clearHourlyChecks(tripId: Long) =
        tripDao.clearHourlyChecksForTrip(tripId)
}
