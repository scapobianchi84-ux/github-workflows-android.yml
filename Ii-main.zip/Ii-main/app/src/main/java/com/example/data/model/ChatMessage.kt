package com.example.data.model

import java.util.UUID

enum class ChatSender {
    USER,
    AI
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: ChatSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val sourceTag: String = if (sender == ChatSender.AI) "Gemini 3.5 Flash" else "Viaggiatore",
    val suggestedFollowUps: List<String> = emptyList()
)
