package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSender
import com.example.data.model.HourlyCheckRecord
import com.example.data.model.Trip
import com.example.data.model.TripStop
import com.example.data.model.WeatherForecastDay
import com.example.data.remote.GeminiVacationService
import com.example.data.remote.WeatherService
import com.example.data.repository.TripRepository
import com.example.domain.AbacusOptimizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class TripViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TripRepository
    private val geminiService = GeminiVacationService()
    private val weatherService = WeatherService()

    val trips: StateFlow<List<Trip>>
    private val _activeTripId = MutableStateFlow<Long?>(null)
    val activeTripId: StateFlow<Long?> = _activeTripId.asStateFlow()

    private val _selectedDay = MutableStateFlow(1)
    val selectedDay: StateFlow<Int> = _selectedDay.asStateFlow()

    private val _selectedStop = MutableStateFlow<TripStop?>(null)
    val selectedStop: StateFlow<TripStop?> = _selectedStop.asStateFlow()

    private val _weatherForecast = MutableStateFlow<List<WeatherForecastDay>>(emptyList())
    val weatherForecast: StateFlow<List<WeatherForecastDay>> = _weatherForecast.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _simulatedDelay = MutableStateFlow(0)
    val simulatedDelay: StateFlow<Int> = _simulatedDelay.asStateFlow()

    // Chat AI state
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatResponding = MutableStateFlow(false)
    val isChatResponding: StateFlow<Boolean> = _isChatResponding.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = TripRepository(db.tripDao())

        trips = repository.allTrips.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Automatically set first trip as active when available
        viewModelScope.launch {
            trips.collect { list ->
                if (list.isNotEmpty() && _activeTripId.value == null) {
                    val firstTrip = list.first()
                    _activeTripId.value = firstTrip.id
                    loadWeatherForTrip(firstTrip)
                    initChatGreeting(firstTrip)
                }
            }
        }
    }

    val activeTrip: StateFlow<Trip?> = _activeTripId
        .flatMapLatest { id ->
            if (id != null) repository.getTripById(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val stops: StateFlow<List<TripStop>> = _activeTripId
        .flatMapLatest { id ->
            if (id != null) repository.getStopsForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dayStops: StateFlow<List<TripStop>> = combine(stops, _selectedDay) { allStops, day ->
        allStops.filter { it.dayNumber == day }.sortedBy { it.orderIndex }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hourlyChecks: StateFlow<List<HourlyCheckRecord>> = _activeTripId
        .flatMapLatest { id ->
            if (id != null) repository.getHourlyChecksForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTrip(trip: Trip) {
        _activeTripId.value = trip.id
        _selectedDay.value = 1
        _selectedStop.value = null
        loadWeatherForTrip(trip)
        initChatGreeting(trip)
    }

    fun selectDay(day: Int) {
        _selectedDay.value = day
        _selectedStop.value = null
    }

    fun selectStop(stop: TripStop?) {
        _selectedStop.value = stop
    }

    fun setSimulatedDelay(minutes: Int) {
        _simulatedDelay.value = minutes
    }

    private fun loadWeatherForTrip(trip: Trip) {
        viewModelScope.launch(Dispatchers.IO) {
            val forecast = weatherService.getForecast(
                destination = trip.destination,
                latitude = trip.latitude,
                longitude = trip.longitude,
                durationDays = trip.durationDays
            )
            _weatherForecast.value = forecast
        }
    }

    fun createTripWithAi(
        destination: String,
        interests: String,
        durationDays: Int,
        budget: Double
    ) {
        viewModelScope.launch {
            _isGenerating.value = true
            try {
                // Step 1: Gemini AI generates destination stops
                val aiDraft = geminiService.generateItinerary(
                    destination = destination,
                    interests = interests,
                    durationDays = durationDays,
                    budget = budget
                )

                // Step 2: Abacus AI balances budget & timings
                val newTrip = Trip(
                    title = "Vacanza a ${aiDraft.destinationTitle}",
                    destination = aiDraft.destinationTitle,
                    interests = interests,
                    durationDays = durationDays,
                    startDate = "Prossima partenza",
                    budgetTotal = budget,
                    budgetSpent = 0.0,
                    latitude = aiDraft.latitude,
                    longitude = aiDraft.longitude,
                    aiModelSummary = "Gemini 3.5 Flash + Abacus Resource Optimizer",
                    status = "In Corso",
                    isHourlyTrackingActive = true,
                    currentDay = 1
                )

                val tripId = repository.insertTrip(newTrip)

                // Convert drafts to Room stops
                val roomStops = aiDraft.stops.map { draft ->
                    TripStop(
                        tripId = tripId,
                        dayNumber = draft.dayNumber,
                        orderIndex = draft.orderIndex,
                        timeSlot = draft.timeSlot,
                        title = draft.title,
                        category = draft.category,
                        description = draft.description,
                        estimatedCost = draft.estimatedCost,
                        durationMinutes = draft.durationMinutes,
                        latitude = draft.latitude,
                        longitude = draft.longitude,
                        addressOrLocation = draft.address,
                        bookingUrl = draft.bookingUrl,
                        bookingStatus = if (draft.estimatedCost > 0) "Da prenotare" else "Non richiesto"
                    )
                }

                repository.insertStops(roomStops)

                // Step 3: Run initial Abacus hourly schedule checkpoint
                val initialAudit = AbacusOptimizer.performHourlyAudit(
                    trip = newTrip.copy(id = tripId),
                    dayStops = roomStops.filter { it.dayNumber == 1 },
                    simulatedDelayMinutes = 0
                )
                repository.insertHourlyCheck(initialAudit)

                // Activate newly created trip
                _activeTripId.value = tripId
                _selectedDay.value = 1
                loadWeatherForTrip(newTrip.copy(id = tripId))
                initChatGreeting(newTrip.copy(id = tripId))
            } catch (e: Exception) {
                // Catch any issues
            } finally {
                _isGenerating.value = false
            }
        }
    }

    private fun initChatGreeting(trip: Trip) {
        val greetingText = """
            Ciao! 👋 Sono la tua **Guida Intelligente Gemini 3.5**.
            
            Ho caricato l'intero programma per il tuo viaggio a **${trip.destination}** (${trip.durationDays} giorni, budget €${trip.budgetTotal.toInt()}).
            
            Conosco tutte le tue tappe programmate, gli orari, le opzioni culinarie, il meteo previsto e le curiosità storiche più affascinanti.
            
            Chiedimi qualsiasi cosa sul viaggio o tocca uno dei suggerimenti qui sotto!
        """.trimIndent()

        _chatMessages.value = listOf(
            ChatMessage(
                sender = ChatSender.AI,
                text = greetingText,
                suggestedFollowUps = listOf(
                    "Curiosità su ${trip.destination}",
                    "Cosa facciamo oggi?",
                    "Cosa mangiare di tipico?",
                    "Consigli per risparmiare sul budget",
                    "Meteo e abbigliamento consigliato"
                )
            )
        )
    }

    fun sendChatMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isBlank() || _isChatResponding.value) return

        val userMessage = ChatMessage(
            sender = ChatSender.USER,
            text = trimmed
        )
        _chatMessages.value = _chatMessages.value + userMessage
        _isChatResponding.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val trip = activeTrip.value
            val currentStops = stops.value
            val currentForecast = weatherForecast.value
            val history = _chatMessages.value

            if (trip != null) {
                val responseText = geminiService.askTripAssistant(
                    trip = trip,
                    stops = currentStops,
                    weather = currentForecast,
                    conversationHistory = history,
                    userQuestion = trimmed
                )

                val aiMessage = ChatMessage(
                    sender = ChatSender.AI,
                    text = responseText,
                    suggestedFollowUps = generateFollowUpsFor(trimmed, trip)
                )
                _chatMessages.value = _chatMessages.value + aiMessage
            } else {
                _chatMessages.value = _chatMessages.value + ChatMessage(
                    sender = ChatSender.AI,
                    text = "Seleziona o crea prima un viaggio per poter esplorare curiosità e dettagli con me!"
                )
            }
            _isChatResponding.value = false
        }
    }

    fun clearChatHistory() {
        val currentTrip = activeTrip.value
        if (currentTrip != null) {
            initChatGreeting(currentTrip)
        } else {
            _chatMessages.value = emptyList()
        }
    }

    private fun generateFollowUpsFor(query: String, trip: Trip): List<String> {
        val q = query.lowercase()
        return when {
            q.contains("curiosit") -> listOf("Altre curiosità e leggende", "Cosa mangiare nei dintorni?", "Tappe del Giorno 1")
            q.contains("cibo") || q.contains("mangiar") -> listOf("Qual è il piatto tipico più famoso?", "Controlla il budget rimanente", "Meteo nei prossimi giorni")
            q.contains("meteo") -> listOf("Cosa fare se piove?", "Curiosità sui monumenti", "Rivedi le tappe di oggi")
            else -> listOf("Curiosità su ${trip.destination}", "Consigli sui ristoranti", "Tappe e orari di domani")
        }
    }

    fun updateStop(stop: TripStop) {
        viewModelScope.launch {
            repository.updateStop(stop)
            if (_selectedStop.value?.id == stop.id) {
                _selectedStop.value = stop
            }
        }
    }

    fun deleteStop(stop: TripStop) {
        viewModelScope.launch {
            repository.deleteStop(stop)
            if (_selectedStop.value?.id == stop.id) {
                _selectedStop.value = null
            }
        }
    }

    fun addNewStop(
        tripId: Long,
        dayNumber: Int,
        title: String,
        timeSlot: String,
        category: String,
        cost: Double,
        duration: Int,
        description: String,
        address: String
    ) {
        viewModelScope.launch {
            val currentDayStops = repository.getStopsForDaySync(tripId, dayNumber)
            val nextOrder = currentDayStops.size
            val activeT = activeTrip.value

            val newStop = TripStop(
                tripId = tripId,
                dayNumber = dayNumber,
                orderIndex = nextOrder,
                timeSlot = timeSlot,
                title = title,
                category = category,
                description = description,
                estimatedCost = cost,
                durationMinutes = duration,
                latitude = activeT?.latitude ?: 41.9028,
                longitude = activeT?.longitude ?: 12.4964,
                addressOrLocation = address
            )
            repository.insertStop(newStop)
        }
    }

    fun toggleStopCompleted(stop: TripStop) {
        viewModelScope.launch {
            val updated = stop.copy(isCompleted = !stop.isCompleted)
            repository.updateStop(updated)
            if (_selectedStop.value?.id == stop.id) {
                _selectedStop.value = updated
            }
            // Trigger automatic hourly audit update
            activeTrip.value?.let { trip ->
                val currentStops = repository.getStopsForDaySync(trip.id, _selectedDay.value)
                val audit = AbacusOptimizer.performHourlyAudit(trip, currentStops, _simulatedDelay.value)
                repository.insertHourlyCheck(audit)
            }
        }
    }

    fun performHourlyCheck() {
        viewModelScope.launch {
            val trip = activeTrip.value ?: return@launch
            val day = _selectedDay.value
            val currentDayStops = repository.getStopsForDaySync(trip.id, day)

            val audit = AbacusOptimizer.performHourlyAudit(
                trip = trip,
                dayStops = currentDayStops,
                simulatedDelayMinutes = _simulatedDelay.value
            )
            repository.insertHourlyCheck(audit)
        }
    }

    fun rebalanceScheduleWithAbacus() {
        viewModelScope.launch {
            val trip = activeTrip.value ?: return@launch
            val day = _selectedDay.value
            val currentDayStops = repository.getStopsForDaySync(trip.id, day)

            val rebalanced = AbacusOptimizer.rebalanceStops(currentDayStops, _simulatedDelay.value)
            rebalanced.forEach { repository.updateStop(it) }

            // Reset simulated delay after auto-rebalance
            _simulatedDelay.value = 0

            // Log resolved checkpoint
            val audit = AbacusOptimizer.performHourlyAudit(trip, rebalanced, 0)
            repository.insertHourlyCheck(
                audit.copy(
                    punctualityStatus = "RICALIBRATO CON SUCCESSO",
                    abacusRecommendation = "Abacus Engine: Itinerario ricalibrato! Tempistiche ottimizzate per recuperare il ritardo e rispettare le prenotazioni serali."
                )
            )
        }
    }
}
